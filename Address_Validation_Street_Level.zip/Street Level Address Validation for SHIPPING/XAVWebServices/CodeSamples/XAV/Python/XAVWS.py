import xml.etree.ElementTree as ET
from zeep import Client, Settings
from zeep.exceptions import Fault, TransportError, XMLSyntaxError

# Set Connection
settings = Settings(strict=False, xml_huge_tree=True)
client = Client('<WSDLLocation>/XAV.wsdl', settings=settings)

# Set SOAP headers
headers = {
    'UPSSecurity': {
        'UsernameToken': {
            'Username': '<Username>',
            'Password': '<password>'
        },
        'ServiceAccessToken': {
            'AccessLicenseNumber': '<AccessLicenseKey>'
        }
    }
}

# Create request dictionary
requestDictionary = {
    "RequestOption": "1"
}
regionalRequestIndicator = ""
maximumCandidateListSize = "10"
addressKeyFormat = {
    "AddressLine": "103 Schroeter Ave",
    "PoliticalDivision2": "Cactus",
    "PoliticalDivision1": "TX",
    "PostcodePrimaryLow": "79013",
    "CountryCode":"US"
}

# Try operation
try:
    response = client.service.ProcessXAV(_soapheaders=headers, Request=requestDictionary,RegionalRequestIndicator=regionalRequestIndicator,
                                         MaximumCandidateListSize=maximumCandidateListSize,AddressKeyFormat=addressKeyFormat)
    print(response)

except Fault as  error:
    print(ET.tostring(error.detail))


